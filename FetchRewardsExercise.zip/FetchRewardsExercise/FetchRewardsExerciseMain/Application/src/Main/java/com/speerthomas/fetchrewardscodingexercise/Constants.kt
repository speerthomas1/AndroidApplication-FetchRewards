package com.speerthomas.fetchrewardscodingexercise

object Constants {

const val FETCH_REWARDS_BASE_URL = "https://fetch-hiring.s3.amazonaws.com/"

}